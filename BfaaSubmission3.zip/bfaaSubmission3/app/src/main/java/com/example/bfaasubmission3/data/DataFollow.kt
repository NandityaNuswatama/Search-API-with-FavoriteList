package com.example.bfaasubmission3.data

data class DataFollow (
    var name: String? = null,
    var avatar: String? = null
)