package com.example.favoriteconsumer.data

data class DataFollow (
    var name: String? = null,
    var avatar: String? = null
)